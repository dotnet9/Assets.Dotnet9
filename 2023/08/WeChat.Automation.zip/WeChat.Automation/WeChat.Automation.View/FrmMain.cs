

using FlaUI.Core.AutomationElements;
using FlaUI.Core.Conditions;
using FlaUI.Core.Definitions;
using FlaUI.UIA3;
using FlaUI.UIA3.Patterns;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;
using WeChat.Automation.View.Chat;

namespace WeChat.Automation.View
{
    public partial class FrmMain : FrmBase
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// ����
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStart_Click(object sender, EventArgs e)
        {
            InitWechat();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {

        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
            GC.Collect();
        }
        private CancellationToken FriendCancellationToken { get; set; }
        private CancellationTokenSource FriendTokenSource { get; set; }
        private CancellationToken ChatListCancellationToken { get; set; }
        private CancellationTokenSource ChatListTokenSource { get; set; }
        private CancellationToken GetFriendCancellationToken { get; set; }
        private CancellationTokenSource GetFriendTokenSource { get; set; }
        /// <summary>
        /// ΢�ŵĽ���ID
        /// </summary>
        private int ProcessId { get; set; }
        /// <summary>
        /// ΢�Ŵ���
        /// </summary>
        private Window wxWindow { get; set; }
        private bool IsInit { get; set; }
        /// <summary>
        /// ��ȡ
        /// </summary>
        void GetWxHandle()
        {
            var process = Process.GetProcessesByName("Wechat").FirstOrDefault();
            if (process != null)
            {
                ProcessId = process.Id;
            }
        }
        /// <summary>
        /// ����΢��
        /// </summary>
        void InitWechat()
        {
            IsInit = true;
            GetWxHandle();
            GetFriendTokenSource = new CancellationTokenSource();
            GetFriendCancellationToken = GetFriendTokenSource.Token;
            ChatListTokenSource = new CancellationTokenSource();
            ChatListCancellationToken = ChatListTokenSource.Token;
            FriendTokenSource = new CancellationTokenSource();
            FriendCancellationToken = FriendTokenSource.Token;
            //����΢�Ž���ID��FLAUI
            try
            {
                var application = FlaUI.Core.Application.Attach(ProcessId);
                var automation = new UIA3Automation();
                //��ȡ΢��window�Զ�����������
                wxWindow = application.GetMainWindow(automation);
            }
            catch (Exception ex)
            {
                if (MessageBox.Show(ex.Message, "�쳣", MessageBoxButtons.OK, MessageBoxIcon.Error) == DialogResult.OK)
                    this.Close();
            }


            // ���غ���
            IsListenCronyList = true;
            // ����������Ϣ
            GetChatInfo();
        }
        /// <summary>
        /// ��ȡ�����б�
        /// </summary>
        void GetFriends()
        {
            if (!IsInit)
            {
                return;
            }
            if (wxWindow == null)
            {
                return;
            }

            if (wxWindow.Patterns.Window.PatternOrDefault != null)
            {
                //��΢�Ŵ�������ΪĬ�Ͻ���״̬
                wxWindow.Patterns.Window.Pattern.SetWindowVisualState(FlaUI.Core.Definitions.WindowVisualState.Normal);
            }

            wxWindow.FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Button)).AsParallel()
                .FirstOrDefault(item => item != null && item.Name == "ͨѶ¼")?.Click(false);

            string lastName = string.Empty;
            var list = new List<AutomationElement>();
            var sync = SynchronizationContext.Current;
            Task.Run(async () =>
            {
                while (true)
                {
                    if (GetFriendCancellationToken.IsCancellationRequested)
                        break;
                    var all = wxWindow.FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.ListItem));
                    var allItem = all.AsParallel().Where(s => s != null && s.Parent != null && "��ϵ��".Equals(s.Parent?.Name)).ToList();
                    foreach (var item in allItem)
                    {
                        if (!string.IsNullOrWhiteSpace(item.Name) && !listBox1.Items.Contains(item.Name.ToString()))
                        {
                            sync.Post(s =>
                            {
                                listBox1.Items.Add(s);
                            }, item.Name.ToString());
                        }

                    }
                    //ScrollEvent(-700);

                    await Task.Delay(1);
                }
            }, GetFriendCancellationToken);
        }
        /// <summary>
        /// ���������б�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnListenCronyList_Click(object sender, EventArgs e)
        {
            IsListenCronyList = !IsListenCronyList;
        }
        private bool _isListenCronyList = false;
        public bool IsListenCronyList
        {
            set
            {
                if (_isListenCronyList == value)
                    return;

                _isListenCronyList = value;
                string txt = string.Empty;
                if (value)
                {
                    txt = "�رռ��������б�";
                    GetFriends();
                }
                else
                {
                    txt = "�������������б�";
                    GetFriendTokenSource.Cancel();
                }
                btnListenCronyList.ExecBeginInvoke(() =>
                {
                    btnListenCronyList.Text = txt;
                });
            }
            get => this._isListenCronyList;
        }
        /// <summary>
        /// ��ȡ������Ϣ
        /// </summary>
        void GetChatInfo()
        {
            if (!IsInit)
            {
                return;
            }
            if (wxWindow == null)
            {
                return;
            }

            //wxWindow.FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Button)).AsParallel().FirstOrDefault(s =>s!=null && s.Name == "����")?.Click(false);
            wxWindow.FindFirstDescendant(cf => cf.ByName("����"))?.Click(false);
            Task.Run(() =>
            {
                AutomationElement? assFirst = null;
                object obj = new object();
                while (true)
                {
                    if (ChatListCancellationToken.IsCancellationRequested)
                    {
                        break;
                    }

                    try
                    {
                        DateTime dateTime3 = DateTime.Now;
                        var searchTextBox = wxWindow.FindFirstDescendant(cf => cf.ByName("�Ự")).AsListBoxItem();

                        if (searchTextBox != null)
                        {
                            var list = searchTextBox.FindAllChildren();
                            if (assFirst == null)
                            {
                                assFirst = list.AsParallel().FirstOrDefault(t => t != null && "�ļ���������".Equals(t.Name));// ���в�ѯ---��Ҫ���ļ����������ö�
                                assFirst?.Click();
                                continue;
                            }

                            Parallel.ForEach(list, item =>
                            {
                                if (item != null && !string.IsNullOrEmpty(item.Name) && !"�۵��ö�����".Equals(item.Name)
                                    && !"��Ѷ����".Equals(item.Name) && !"Ⱥ��".Contains(item.Name))
                                {
                                    DateTime t1= DateTime.Now;
                                    var allText = item.FindAllByXPath(".//Text");//   ��λԪ�صľֲ������� .//Text��   ȫ�������� //*/Text
                                    DateTime t2 = DateTime.Now;
                                    Trace.WriteLine($"allText��ʱ��{(t2 - t1).TotalMilliseconds}ms");
                                    // �ظ���Ϣ�б���δ�ظ���
                                    if (allText != null && allText.Length >= 4)
                                    {
                                        if (int.TryParse(allText[3].Name, out var count) && count > 0)
                                        {
                                            lock (obj)
                                            {
                                                var name = allText[0].Name;
                                                var time = allText[1].Name;
                                                var content = allText[2].Name;
                                                if (wxWindow.Patterns.Window.PatternOrDefault != null)
                                                {
                                                    //��΢�Ŵ�������ΪĬ�Ͻ���״̬
                                                    wxWindow.Patterns.Window.Pattern.SetWindowVisualState(FlaUI.Core.Definitions.WindowVisualState.Normal);
                                                }

                                                item.Click();
                                                DateTime t7= DateTime.Now;
                                                var itemFirst = wxWindow.FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Text)).AsParallel()
                                                .FirstOrDefault(t =>t!=null && t.Parent.ControlType == ControlType.Pane && !t.IsOffscreen && t.Name.Trim().IsSpecificNumbers());
                                                DateTime t8= DateTime.Now;
                                                Trace.WriteLine($"itemFirst��{(t8 - t7).TotalMilliseconds}ms");
                                                // �ж��Ƿ�ΪȺ��
                                                if (itemFirst == null)
                                                {
                                                    AutoGetMesg(content);
                                                }
                                                assFirst?.Click();
                                            }
                                        }
                                    }
                                }
                            });

                            DateTime dateTime4 = DateTime.Now;
                            Trace.WriteLine($"����888��ʱ��{(dateTime4 - dateTime3).TotalMilliseconds}ms");
                        }
                        else
                        {
                            Thread.Sleep(10);
                            continue;
                        }

                        //ScrollEvent(-700);

                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                    finally
                    {
                        //await Task.Delay(1);
                    }
                }
            }, ChatListCancellationToken);
        }
        IChat _chat;
        private void AutoGetMesg(string txt)
        {
            if (_chat == null)
            {
                _chat = new ChatAchieve();
                _chat.RequestContent = GetMessage;
            }
            Trace.WriteLine($"������Ϣ��{txt}");
            _chat.RequestGPT(txt);
        }

        private FlaUI.Core.AutomationElements.TextBox _mesText;
        public FlaUI.Core.AutomationElements.TextBox MesText
        {
            get
            {
                if (_mesText == null)
                    _mesText = wxWindow.FindFirstDescendant(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Text)).AsTextBox();

                return _mesText;
            }
        }
        private AutomationElement? _btnSend;
        public AutomationElement? btnSend
        {
            get
            {
                if (_btnSend == null)
                {
                    _btnSend = wxWindow.FindFirstDescendant(cf => cf.ByName("sendBtn"));
                    //_btnSend = wxWindow.FindAllDescendants(x => x.ByControlType(FlaUI.Core.Definitions.ControlType.Button)).FirstOrDefault(s => s.Name == "����(S)");
                }

                return _btnSend;
            }
        }
        const int _offSize = 300;
        private void GetMessage(string mes)
        {
            SendMes(mes);
            Trace.WriteLine($"�ظ���{mes}");
        }
        private void SendMes(string mes)
        {
            if (wxWindow.Patterns.Window.PatternOrDefault != null)
            {
                //��΢�Ŵ�������ΪĬ�Ͻ���״̬
                wxWindow.Patterns.Window.Pattern.SetWindowVisualState(FlaUI.Core.Definitions.WindowVisualState.Normal);
            }
            int tempLen = 0;
            string txt = string.Empty;
            try
            {
                if (!string.IsNullOrWhiteSpace(mes))
                {
                    string[] lines = mes.Split(Environment.NewLine);

                    foreach (string line in lines)
                    {
                        tempLen += line.Length;
                        txt += line + Environment.NewLine;
                        if (tempLen > _offSize)
                        {
                            MesText.Text = txt;
                            btnSend?.Click();
                            tempLen = 0;
                            txt = string.Empty;
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(txt))
                    {
                        MesText.Text = txt;
                        Thread.Sleep(3);
                        btnSend?.Click();
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                MesText.Text = txt;
                btnSend?.Click();
            }
        }
    }
}