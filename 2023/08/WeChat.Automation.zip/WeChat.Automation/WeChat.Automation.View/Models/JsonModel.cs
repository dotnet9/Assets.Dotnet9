﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace WeChat.Automation.View.Models
{
    public class JsonModel
    {
        public RequestInfo RequestInfo { get; set; }
    }
    public class RequestInfo
    {
        /// <summary>
        /// 
        /// </summary>
        public int bitoUserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<RequestContext> context { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string email { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ideName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string outputLanguage { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string prompt { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string requestId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string sessionId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool stream { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string uId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int wsId { get; set; }
        public override string ToString()
        {
            return JsonSerializer.Serialize(this);
        }
    }
    public class RequestContext
    {
        public string answer { get; set; }
        public string question { get; set; }
    }
}
