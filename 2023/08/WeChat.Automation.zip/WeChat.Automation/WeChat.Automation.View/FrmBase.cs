﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeChat.Automation.View
{
    public partial class FrmBase : Form
    {
        public FrmBase()
        {
            InitializeComponent();
        }
        /// <summary>
        ///  Scroll Event
        /// </summary>
        /// <param name="scroll"></param>
        public void ScrollEvent(int scroll)
        {
            INPUT[] inputs = new INPUT[1];

            // 设置鼠标滚动事件
            inputs[0].type = InputType.INPUT_MOUSE;
            inputs[0].mi.dwFlags = MouseEventFlags.MOUSEEVENTF_WHEEL;
            inputs[0].mi.mouseData = (uint)scroll;

            // 发送输入事件
            User32.SendInput(1, inputs, Marshal.SizeOf(typeof(INPUT)));
        }
       

    }
}
