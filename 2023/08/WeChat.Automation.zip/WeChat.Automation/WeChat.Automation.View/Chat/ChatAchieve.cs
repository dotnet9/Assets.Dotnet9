﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace WeChat.Automation.View.Chat
{
    public class ChatAchieve : IChat
    {
        private byte[] _data = new byte[10240];

        private static Random _random = new Random();

        private long _id = (long)_random.Next();

        public Action<string> RequestContent { get; set; }
        public Action<StringBuilder> RequestMesage { get; set; }
        public ChatAchieve()
        {
            _id = DateTimeOffset.Now.ToUnixTimeMilliseconds();
        }
        public void RequestGPT(string content)
        {
            HTTPRequestGPT(content);
            //StringBuilder stringBuilder = new StringBuilder();
            //stringBuilder.AppendLine("牛顿三大定律，也称为牛顿运动定律，是经典力学的基本定律，由英国物理学家艾萨克·牛顿在17世纪末提出。这些定律描述了物体的运动以及作用力的关系，对于理解力学系统的行为非常重要。以下是牛顿三大定律的简要介绍：");
            //stringBuilder.AppendLine("1.第一定律（惯性定律）：当作用于一个物体的合力为零时，物体将保持静止或匀速直线运动。换句话说，物体会保持原有的状态，包括静止和匀速直线运动。这意味着物体不会自发地改变其运动状态，除非有外力作用。");
            //stringBuilder.AppendLine("2.第二定律（动量定律）：物体的加速度与作用在其上的力成正比，与物体质量成反比。具体表达式为F=ma，其中F表示作用在物体上的合力，m表示物体的质量，a表示物体的加速度。换句话说，当一个物体受到作用力时，它会产生加速度，其大小与施加在物体上的力成正比，与物体的质量成反比。");
            //stringBuilder.AppendLine("3.第三定律（作用-反作用定律）：任何作用在物体上的力都会有一个等大但方向相反的反作用力。换句话说，对于任何两个物体之间的相互作用，其中一个物体施加在另一个物体上的力，必然存在着一个等大但方向相反的力作用在第一个物体上。这意味着力总是成对出现的。");
            //stringBuilder.AppendLine("这三条定律共同描述了物体的运动和受力规律，为我们理解和解释自然界中的力学现象提供了基础。");
            //RequestContent?.Invoke(stringBuilder.ToString());
        }
        private void HTTPRequestGPT(string content)
        {
            try
            {
                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(new Uri("https://api.aichatos.cloud/api/generateStream"));
                httpWebRequest.Method = "POST";
                httpWebRequest.Accept = "application/json, text/plain, */*";
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Headers.Add("Accept-Encoding", "gzip, deflate, br");
                httpWebRequest.Headers.Add("Accept-Language", "zh-CN,zh;q=0.9");
                httpWebRequest.Headers.Add("Origin", "https://dev.yqcloud.top");
                httpWebRequest.Headers.Add("Aec-ch-ua", "\"Chromium\";v=\"112\", \"Google Chrome\";v=\"112\", \"Not: A - Brand\";v=\"99\"");
                httpWebRequest.Headers.Add("Sec-Ch-Ua", "\"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"114\", \"Google Chrome\";v=\"114\"");
                httpWebRequest.Headers.Add("Sec-Ch-Ua-Mobile", "?0");
                httpWebRequest.Headers.Add("Sec-ch-ua-platform", "\"Windows\"");
                httpWebRequest.Headers.Add("Sec-Fetch-Dest", "empty");
                httpWebRequest.Headers.Add("Sec-Fetch-Mode", "cors");
                httpWebRequest.Headers.Add("Sec-Fetch-Site", "cross-site");
                httpWebRequest.Referer = "https://dev.yqcloud.top/";
                httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36";
                httpWebRequest.Host = "api.aichatos.cloud";
                using Stream requestStream = httpWebRequest.GetRequestStream();
                var json = " {\"prompt\":\"" + content + "\",\"userId\":\"#/chat/" + _id + "\",\"network\":true,\"system\":\"\",\"withoutContext\":false,\"stream\":false}";
                byte[] bytes = Encoding.UTF8.GetBytes(json);
                // 设置请求内容长度
                httpWebRequest.ContentLength = bytes.Length;
                requestStream.Write(bytes, 0, bytes.Length);

                ExResponse(httpWebRequest);

                //using WebResponse response = httpWebRequest.GetResponse();
                //using Stream responseStream = response.GetResponseStream();

                //using StreamReader reader = new StreamReader(responseStream);
                //string responseText = reader.ReadToEnd();
                //RequestContent?.Invoke(responseText);

                //int num = 0;
                //int num2 = 0;
                //int num3 = 0;
                //StringBuilder stringBuilder = new StringBuilder();
                //do
                //{
                //    num2 = responseStream.Read(_data, num, 10240 - num);
                //    num += num2;
                //    if (num - num3 >= 3)
                //    {
                //        string mes = Encoding.UTF8.GetString(_data, num3, num - num3);
                //        stringBuilder.Append(mes);
                //        num3 += num - num3;
                //    }
                //}
                //while (num2 != 0);
                //RequestContent?.Invoke(stringBuilder.ToString());

            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
            }
        }
        private void ExResponse(HttpWebRequest request)
        {
            StringBuilder stringBuilder = new StringBuilder();
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                using (Stream responseStream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(responseStream))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            // 在这里对每行字符串进行处理
                            //Console.WriteLine(line);
                            line = line.Trim().Replace("\r", "").Replace("\n", "").Replace(" ", "");
                            if (!string.IsNullOrWhiteSpace(line))
                            {
                                stringBuilder.AppendLine(line);
                            }
                        }
                    }
                }
            }
            
            RequestMesage?.Invoke(stringBuilder);
            RequestContent?.Invoke(stringBuilder.ToString());
        }
    }
}
