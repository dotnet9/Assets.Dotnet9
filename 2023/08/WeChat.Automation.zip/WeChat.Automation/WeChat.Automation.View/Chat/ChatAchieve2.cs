﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.Json;
using System.Threading.Tasks;
using WeChat.Automation.View.Models;

namespace WeChat.Automation.View.Chat
{
    public class ChatAchieve2 : IChat
    {
        private byte[] _data = new byte[10240];
        private readonly HttpClient _client;
        private const string _url = "https://bitoai.bito.ai/ai/v2/chat/?processSilently=true";
        private readonly JsonModel _requestInfo;
        public ChatAchieve2()
        {
            // 读取JSON文件内容
            string json = File.ReadAllText(Path.Combine(Application.StartupPath, "jsconfig1.json"));
            _requestInfo = JsonSerializer.Deserialize<JsonModel>(json);

            _client = new HttpClient();
            _client.Timeout = TimeSpan.FromSeconds(20);
            _client.DefaultRequestHeaders.Add("Accept", "*/*");
            _client.DefaultRequestHeaders.Add("Accept-Encoding", "gzip, deflate, br");
            _client.DefaultRequestHeaders.Add("Accept-Language", "en-US");
            _client.DefaultRequestHeaders.Add("authorization", "636192109620703257");
            //_client.DefaultRequestHeaders.Add("Content-Type", "application/json");
            _client.DefaultRequestHeaders.Add("Origin", "vscode-webview://1ghcg6a4vv585v6ft5fo8m1pkuel03ifdou24i1kbn472fljv5eg");
            _client.DefaultRequestHeaders.Add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.80.1 Chrome/108.0.5359.215 Electron/22.3.14 Safari/537.36");
        }
        public Action<string> RequestContent { get; set; }

        public void RequestGPT(string content)
        {
            _requestInfo.RequestInfo.prompt = content;
            _requestInfo.RequestInfo.requestId = Guid.NewGuid().ToString();
            SendPostRequest2(_url, _requestInfo.RequestInfo.ToString());
        }
        public void SendPostRequest2(string url, string data)
        {
            HttpContent content = new StringContent(data);
            HttpResponseMessage response = _client.PostAsync(url, content).Result;
            response.EnsureSuccessStatusCode();
            using var sm = response.Content.ReadAsStream();
            int num = 0;
            int num2 = 0;
            int num3 = 0;
            do
            {
                num2 = sm.Read(_data, num, 10240 - num);
                num += num2;
                if (num - num3 >= 3)
                {
                    string mes = Encoding.UTF8.GetString(_data, num3, num - num3);
                    RequestContent?.Invoke(mes);
                    num3 += num - num3;
                }
            }
            while (num2 != 0);
        }
        public string SendGetRequest2(string url)
        {
            HttpResponseMessage response = _client.GetAsync(url).Result;
            response.EnsureSuccessStatusCode();
            using var sm = response.Content.ReadAsStream();
            int num = 0;
            int num2 = 0;
            int num3 = 0;
            do
            {
                num2 = sm.Read(_data, num, 10240 - num);
                num += num2;
                if (num - num3 >= 3)
                {
                    RequestContent?.Invoke(Encoding.UTF8.GetString(_data, num3, num - num3));
                    num3 += num - num3;
                }
            }
            while (num2 != 0);
            string result = response.Content.ReadAsStringAsync().Result;
            return result;
        }
        public string SendGetRequest(string url)
        {
            HttpResponseMessage response = _client.GetAsync(url).Result;
            response.EnsureSuccessStatusCode();
            string result = response.Content.ReadAsStringAsync().Result;
            return result;
        }

        public string SendPostRequest(string url, string data)
        {
            HttpContent content = new StringContent(data);
            HttpResponseMessage response = _client.PostAsync(url, content).Result;
            response.EnsureSuccessStatusCode();
            string result = response.Content.ReadAsStringAsync().Result;
            return result;
        }
        public async Task<string> SendGetRequestAsync(string url)
        {
            using HttpResponseMessage response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();
            string result = await response.Content.ReadAsStringAsync();
            return result;
        }
        public async Task<string> SendPostRequestAsync(string url, string data)
        {
            using HttpContent content = new StringContent(data);
            using HttpResponseMessage response = await _client.PostAsync(url, content);
            response.EnsureSuccessStatusCode();
            string result = await response.Content.ReadAsStringAsync();
            return result;
        }
    }
}
